---
title: 日志查看命令
date: 2016-05-30 22:52:29
tags:
categories: 采石场
---
#### 稍微记录几个常用的查看日志的命令。
- 查看Docker日志
```
docker logs --tail=100 -f {container-name/id}
```
- 查看Nginx日志
```
sudo tail -f /path/access.log
sudo tail -f /path/error.log
```
<!--more-->
- Cat命令查看文件内容
```
cat ~/.ssh/id_rsa.pub
```
