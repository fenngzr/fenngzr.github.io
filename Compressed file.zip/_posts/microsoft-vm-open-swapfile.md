---
title: 开启微软服务器的swap功能
date: 2016-05-31 17:41:28
tags: [swap,swapfile,ubuntu14.04]
categories: 采石场
---
- root用户登陆服务器，查看系统信息
```
cat /etc/issue
```

>Ubuntu 14.04.4 LTS \n \l

- 先备份waagent.conf
```
sudo cp /etc/waagent.conf /etc/waagent.conf.org
```
<!--more-->
- 修改waagent.conf
```
sudo vim /etc/waagent.conf
```

>ResourceDisk.Format=n            -> Change to         ResourceDisk.Format=y
ResourceDisk.EnableSwap=n        -> Change to         ResourceDisk.EnableSwap=y
ResourceDisk.SwapSizeMB=0        -> Change to         ResourceDisk.SwapSizeMB=2048

- 重启服务
```
service walinuxagent restart
```
- 开启swap
```
swapon -s
```
- 确认swap信息
```
cat /proc/swaps
```

>Filename                                Type            Size    Used    Priority
/mnt/swapfile                           file            2097148 0       -1

- ```
file /mnt/swapfile
```

>/mnt/swapfile: Linux/i386 swap file (new style), version 1 (4K pages), size 524287 pages, no label,UUID=aa3097ce-84e3-49a9-b6fb-ab50bcff7823

- 检查swap是否生效
```
free
```
