---
title: 安装Docker/Nginx/Nodejs/Git/Mongodb
date: 2016-04-24 17:41:28
tags: [Docker,Nginx,Nodejs,Git,Mongodb,Ubuntu]
categories: 采石场
---
*********************************
- ##### 检查更新
 `sudo apt-get update`
#### 安装Nginx
- ##### 下载nginx官方公钥
`wget http://nginx.org/keys/nginx_signing.key`
<!--more-->
- ##### 检查是否新增了nginx_signing.key文件
`ls`
- ##### 添加key到vps
`sudo apt-key add nginx_signing.key`
- ##### 添加官方包源
`sudo vim /etc/apt/sources.list`     `add the rep to sources.list`

- ##### 在文件最下方加入该两行代码，如下：
   ` deb http://nginx.org/packages/ubuntu/ trusty nginx`
   ` deb-src http://nginx.org/packages/ubuntu/ trusty nginx`  
    `Ubuntu版本是14.04，对应的codename为：trusy`
- ##### 同步list里的包索引文件
`sudo apt-get update`
- ##### 安装Nginx
`sudo apt-get install nginx`
- ##### 检查是否安装完毕
`sudo nginx –v `
#### 安装Nvm /Nodejs
- ##### 注意安装的用户权限
- ##### 通过脚本安装Nvm，并将包源加进了.profile
`curl -o- https://raw.githubusercontent.com/creationix/nvm/v0.31.0/install.sh | bash`
- ##### 让.profile文件生效
`source ~/.profile`
- ##### 查看Node的所有版本
`nvm ls-remote `
- ##### 安装以5开头的最新Node版本
`nvm install v5`
- ##### 默认使用Nodejs的v5版本
`nvm alias default v5`
#### 安装git
- ##### 直接使用Apt-get包管理工具安装git，以前有个软件叫git，所有用git-core
`sudo apt-get install git-core`
#### 安装docker
- ##### 添加官方包源
`sudo vim /etc/apt/sources.list.d/docker.list`
`deb https://apt.dockerproject.org/repo ubuntu-trusty main`
- ##### 添加官方GPG key
`sudo apt-key adv --keyserver hkp://p80.pool.sks-keyservers.net:80 --recv-keys 58118E89F3A912897C070ADBF76221572C52609D`
- ##### 更新系统
`sudo apt-get update`
#### 安装docker
- ##### 直接使用Apt-get包管理工具安装Docker
`sudo apt-get install docker-engine`
- ##### 查看版本
`docker -version`
- ##### 附注：Docker的卸载
https://nurmrony.wordpress.com/2015/05/06/uninstall-docker-from-ubuntu-14-04/docker
- ##### docker下跑nodejs
`sudo docker run -it node:5 node -v`
- ##### Docker下跑MongoDB
`sudo docker run --name some-mongo -d mongo`
- ##### 创建docker组，并添加用户
`sudo usermod -aG docker fengzr`
