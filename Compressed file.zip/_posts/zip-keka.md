---
title: Mac下使用Keka-解决windows下解压乱码的问题
date: 2016-08-17 13:58:54
tags: [keka,zip]
categories: 采石场
---


工作中，常常需要将文件以压缩包的方式，传给项目组其他成员。
经常出现一个问题：Mac下压缩的Zip文件，在Windows解压后，可能出现乱码，甚至是无法打开该压缩文件。

通过查资料，发现一款能很友好的支持Mac和Windows的压缩文件---[Keka](http://www.kekaosx.com/en/)。

### 介绍
Keka是一个免费的MacOSX文件解压缩程序。支持的文件压缩格式：7z、Zip、Tar、Gzip、Bzip2、DMG和ISO。
### 安装
安装很简单，下载安装即可。
<!--more-->
### 使用
双击打开程序，会看到软件的图形界面，如下图


![程序主界面](zip-keka/keka1.png)

选择需要压缩的格式，将需要压缩的文件/文件夹，拖入这个程序即可完成压缩
![文件拖进主面板--界面发生变化](zip-keka/keka2.png)
压缩完成后，会自动命名压缩包
![单个文件压缩--以该文件名命名](zip-keka/keka3.png)

![多个文件压缩--默认为Compressed file.zip](zip-keka/keka4.png)
测试时，对多个文件/文件夹进行压缩后--其中包含中文/英文名的文件。
在windows下解压，没有出现乱码或无法打开的状况。
