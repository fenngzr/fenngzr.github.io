---
title: 服务器的迁移
date: 2016-06-27 18:20:55
tags: [Docker,MongoDB,Ubuntu]
categories: 采石场
---

#### 情况说明：
- 将老服务器A上的十几个服务，迁移至新服务器B上。
- A目前nginx的server name为a.xxxxxxx.com，如下：
```
server {
        listen 0.0.0.0:80;
        server_name  a.xxxxxxx.com;

        access_log /data/log/nginx/access.log;
        error_log /data/log/nginx/error.log;

       location / {
           proxy_pass http://localhost:4300;
				        }
        }
```
<!--more-->
#### 思路：
1.将域名从A服务器解析到B服务器
2.所有的请求，都通过B去重定向到A来实现
3.逐步在B服务器上部署项目，每部署一个项目即可修改B服务器上的nginx配置，由`proxy_pass重定向`到`proxy_pass本地服务`
#### 操作步骤：
- 在A服务器上新配置一个nginx，server name为b.xxxxxxx.com，如下
```
server {
        listen 0.0.0.0:80;
        server_name  b.xxxxxxx.com;

        access_log /data/log/nginx/access.log;
        error_log /data/log/nginx/error.log;

       location / {
           proxy_pass http://localhost:4300;
				        }
        }
```
- 在B服务器上，添加host，内容为：
```
b.xxxxxxx.com  xx.xx.xx.xx(A的Ip)
```
- 在B服务器上，检验host是否生效
```
ping b.xxxxxxx.com  //能ping通，则生效了
```
- 在B服务器上，配置nginx，server name为a.xxxxxxx.com,其中配置内容如下：
```
server {
        listen 0.0.0.0:80;
        server_name  a.xxxxxxx.com;

		access_log /data/log/nginx/access.log;
		error_log /data/log/nginx/error.log;

        location / {
	           proxy_pass http://b.xxxxxxx.com;
			       }
        }
```
- 在本地修改添加host，内容为：
```
a.xxxxxxx.com  xx.xx.xx.xx(B的Ip)
```
- 在浏览器打开一个`a.xxxxxxx.com`的接口进行测试，看是否能请求到内容
- 在B服务器上，查看Nginx日志，如果有请求日志，则说明：`现在访问a.xxxxxxx.com的接口，会先到B服务器的nginx，然后重定向到A服务器的b.xxxxxxx.com域名`
- 将a.xxxxxxx.com的域名解析到B服务器
