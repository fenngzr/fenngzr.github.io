---
title: Docker下redis、nodejs和mongodb的安装与测试
date: 2016-06-14 11:41:28
tags: [Docker,Nodejs,Mongodb,Ubuntu,redis]
categories: 采石场
---
### 1.Docker下Redis的安装与测试
- 安装
```
docker run --name some-redis -d redis
```
<!--more-->
- 测试
```
docker exec -i -t some-redis bash
root@f440e0651bf0:/data# redis-cli  
127.0.0.1:6379>   
127.0.0.1:6379> set test hello
OK
127.0.0.1:6379> get test
"hello"
127.0.0.1:6379> exit
```
### 2.Docker下Mongodb的安装与测试
- 安装
```
 docker run --name mongo  --restart=always -v /etc/localtime:/etc/localtime:ro  -v /data/db/mongodb/:/data/db  -d mongo  --smallfiles
```
- 测试
```
docker run -it --link mongo:mongo --rm mongo sh -c 'exec mongo "$MONGO_PORT_27017_TCP_ADDR:$MONGO_PORT_27017_TCP_PORT/test"'

MongoDB shell version: 3.2.6
connecting to: 172.17.0.2:27017/test
Welcome to the MongoDB shell.
For interactive help, type "help".
For more comprehensive documentation, see
	http://docs.mongodb.org/
Questions? Try the support group
	http://groups.google.com/group/mongodb-user
Server has startup warnings:
2016-06-13T14:35:16.738+0800 I CONTROL  [initandlisten]
2016-06-13T14:35:16.738+0800 I CONTROL  [initandlisten] ** WARNING: /sys/kernel/mm/transparent_hugepage/enabled is 'always'.
2016-06-13T14:35:16.738+0800 I CONTROL  [initandlisten] **        We suggest setting it to 'never'
2016-06-13T14:35:16.738+0800 I CONTROL  [initandlisten]
2016-06-13T14:35:16.738+0800 I CONTROL  [initandlisten] ** WARNING: /sys/kernel/mm/transparent_hugepage/defrag is 'always'.
2016-06-13T14:35:16.738+0800 I CONTROL  [initandlisten] **        We suggest setting it to 'never'
2016-06-13T14:35:16.738+0800 I CONTROL  [initandlisten]
>
```

### 3.Docker下Nodejs的安装与测试
`参照官网：https://nodejs.org/en/docs/guides/nodejs-docker-webapp/`
- 创建Node.js程序
```
mkdir newfile
cd newfile
vi package.json  //描述该程序和它的依赖
```
- package.json填以下内容

```
{
  "name": "docker_web_app",
  "version": "1.0.0",
  "description": "Node.js on Docker",
  "author": "First Last <first.last@example.com>",
  "main": "server.js",
  "scripts": {
    "start": "node server.js"
  },
  "dependencies": {
    "express": "^4.13.3"
  }
}
```
- 创建js文件
```
vi server.js
```
`js文件里填如下内容`
```
'use strict';

const express = require('express');

// Constants
const PORT = 8080;

// App
const app = express();
app.get('/', function (req, res) {
  res.send('Hello world\n');
});

app.listen(PORT);
console.log('Running on http://localhost:' + PORT);
```
- 创建Dockerfile
```
vi Dockerfile
```
- ``里面内容如下`
```
FROM node:argon

# Create app directory
RUN mkdir -p /usr/src/app
WORKDIR /usr/src/app

# Install app dependencies
COPY package.json /usr/src/app/
RUN npm install

# Bundle app source
COPY . /usr/src/app

EXPOSE 8080
CMD [ "npm", "start" ]
```
- 创建镜像
```
docker build -t <your username>/node-web-app .
```
- 运行
```
docker run -p 49160:8080 -d <your username>/node-web-app
```
