---
title: 进入Docker管理Mongo数据库（一）
date: 2016-04-24 18:20:55
tags: [Docker,MongoDB,Ubuntu]
categories: 采石场
---
**********************************
- #### 进入docker容器
 ``` bash
 docker exec -i -t xxx bash
 ```
- #### 进入mongo
``` bash
mongo
```
<!--more-->
- #### 查看数据库
``` bash
show dbs
```
- #### 选择数据库
``` bash
use Germany
```
- #### 查看表单
``` bash
show collections
```
- #### 查看表单内容
``` bash
db.germany.find()
```
- #### 删除该表单所有数据
``` bash
db.germany.remove( { } )
```
- #### 参考链接：
http://www.tutorialspoint.com/mongodb/mongodb_create_database.htm
https://docs.mongodb.org/manual/reference/method/db.collection.remove/
