---
title: 把文件放至服务器上生成Url
date: 2016-04-24 18:31:23
tags: [Url,Nginx]
categories: 采石场
---
*******************************
- #### 以Json文件为例
- #### 将文件放至服务器的某一目录下
``` bash
/User/project/ABC.json
//比如讲一个名为ABC的Json文件放至project目录下
```
<!--more-->
- #### 配置nginx
``` bash
location /whaterver {
        alias /User/project/;
}
```
- #### 重启nginx
``` bash
sudo service nginx restart
```
- #### 打开浏览器，输入以下地址，即可访问
`www.yourdomain.com/whaterver/ABC.json`
