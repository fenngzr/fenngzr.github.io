---
title: 总结几种解压方法
date: 2016-05-12 17:57:38
tags: [tar,unrar,gzip]
categories: 采石场
---
#### 主要记录一下，自己在LINUX环境下碰到的压缩与解压缩方法
- 压缩为gz格式
```
tar -zcvf filename.tar.gz /dir/log
```
- 解压gz格式
```
tar xf filename.tar.gz
```
- 解压rar格式
`需要先安装unrar工具`
```
sudo apt-get install unrar
unrar x filename.rar
```
