---
title: 进入Docker管理Mongo数据库（二）
date: 2016-06-01 18:20:55
tags: [Docker,MongoDB,Ubuntu]
categories: 采石场
---
最近总碰到数据库管理的问题，总结一下。
- 进入数据库后，查找某一条数据
```
> db.collection.find({projectId:12})
```
- 显示内容如下
```
{ "_id" : ObjectId("111"), "isDelete" : "0", "pubTime" : "", "projectCreateTime" : , "projectStatus" : 1, "projectId" : 12, "masterId" : "", "picLinks" : "", "projectComment" : "", "title" : "【", "list" : [ "20267271", "20267269", "20267283", "20267265", "20267282", "20267270", "20267279", "20267255", "20262041", "20267268", "20260774", "20268485", "20269391", "20270718", "20270695", "20270655", "20270586", "20271744", "20272525" ], "newsType" : "2", "imges" : [ ], "_abstract" : "0", "__v" : 0 }
```
<!--more-->
- 删除这条数据
```
db.collection.remove({_id:ObjectId("111")})
```
- 更新list数组
```
db.collection.update ({"projectId”:12},{$set:{"list": ["19185804", "19183255", "19175356", "19156716", "19138980", "19132215"]}}) #注意：新更新的list数据，会替换掉已有的
```
